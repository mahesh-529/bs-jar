import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Crisis }         from './crisis.service';

@Component({
  template: `
  <div *ngIf="crisis">
    <div>
      <label>Id: </label>{{ crisis.id }}
    </div>
    <div>
      <label>Name: </label>{{crisis.name}}
    </div>
  </div>
  `
})
export class CrisisDetailComponent implements OnInit {

  crisis: Crisis;

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.route.data
      .subscribe((data: { crisis: Crisis }) => {
        this.crisis = data.crisis;
      });
  }

}
