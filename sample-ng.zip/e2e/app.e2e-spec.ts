import { SampleNgPage } from './app.po';

describe('sample-ng App', function() {
  let page: SampleNgPage;

  beforeEach(() => {
    page = new SampleNgPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
