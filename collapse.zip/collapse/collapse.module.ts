import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CollapseRoutingModule } from './collapse-routing.module';
import { CollapseComponent } from './collapse.component';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { CollapseBasicComponent } from './collapse-basic/collapse-basic.component';

@NgModule({
  imports: [
    CommonModule,
    CollapseRoutingModule,
    NgbModule
  ],
  declarations: [
    CollapseComponent,
    CollapseBasicComponent
  ],
  providers: []
})
export class CollapseModule { }
