import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collapse',
  templateUrl: './collapse.component.html',
  styleUrls: ['./collapse.component.css']
})
export class CollapseComponent implements OnInit {
  
  public isCollapsed = false;

  constructor() { }

  ngOnInit() {
  }

  expanded() {
    document.querySelector('.card').classList.toggle('card-fullscreen');
        // $(this).closest('.panel').toggleClass('panel-fullscreen');
  }

}
